import 'dart:io';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'add_edit_screen.dart';
import 'export_service.dart';
import 'home_screen.dart';
import 'photo_viewer.dart';
import 'store.dart';
import 'warranty_item.dart';

class DetailScreen extends StatelessWidget {
  final WarrantyStore store;
  final int itemId;
  const DetailScreen({super.key, required this.store, required this.itemId});

  Widget _row(String label, String? value) {
    if (value == null || value.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
              width: 110,
              child: Text(label, style: const TextStyle(color: Colors.grey))),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  Future<void> _call(BuildContext context, String number) async {
    try {
      final ok = await launchUrl(Uri(scheme: 'tel', path: number));
      if (!ok && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('کال شروع نہیں ہو سکی')));
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('کال شروع نہیں ہو سکی')));
      }
    }
  }

  Future<void> _share(BuildContext context, WarrantyItem item) async {
    try {
      await ExportService.shareItem(item);
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('شیئر نہیں ہو سکا')));
      }
    }
  }

  Future<void> _confirmDelete(BuildContext context, WarrantyItem item) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف کریں؟'),
        content: Text('"${item.name}" کا ریکارڈ مستقل طور پر ختم ہو جائے گا۔'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('منسوخ')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('حذف کریں')),
        ],
      ),
    );
    if (ok == true) {
      await store.remove(item);
      if (context.mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final matches = store.items.where((e) => e.id == itemId);
        if (matches.isEmpty) return const Scaffold(body: SizedBox.shrink());
        final item = matches.first;
        final color = statusColor(item);
        return Scaffold(
          appBar: AppBar(
            title: Text(item.name),
            actions: [
              IconButton(
                tooltip: 'شیئر',
                icon: const Icon(Icons.share),
                onPressed: () => _share(context, item),
              ),
              IconButton(
                tooltip: 'ترمیم',
                icon: const Icon(Icons.edit),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) =>
                          AddEditScreen(store: store, item: item)),
                ),
              ),
              IconButton(
                tooltip: 'حذف',
                icon: const Icon(Icons.delete_outline),
                onPressed: () => _confirmDelete(context, item),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (item.imagePaths.isNotEmpty)
                SizedBox(
                  height: 200,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: item.imagePaths.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (_, i) => GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => PhotoViewer(
                              paths: item.imagePaths, initialIndex: i),
                        ),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.file(
                          File(item.imagePaths[i]),
                          height: 200,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const SizedBox(
                              width: 120,
                              child: Center(child: Icon(Icons.broken_image))),
                        ),
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 16),
              Card(
                color: color.withOpacity(0.1),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(statusText(item),
                          style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: color)),
                      const SizedBox(height: 10),
                      LinearProgressIndicator(
                        value: item.progress,
                        color: color,
                        minHeight: 8,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      const SizedBox(height: 8),
                      Text('ختم ہونے کی تاریخ: ${fmtDate(item.expiryDate)}'),
                    ],
                  ),
                ),
              ),
              if (item.servicePhone != null)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: FilledButton.tonalIcon(
                    onPressed: () => _call(context, item.servicePhone!),
                    icon: const Icon(Icons.phone),
                    label: Text('سروس سینٹر کال کریں: ${item.servicePhone}'),
                  ),
                ),
              const SizedBox(height: 8),
              _row('تاریخ خرید', fmtDate(item.purchaseDate)),
              _row('وارنٹی کی مدت', warrantyLabel(item.warrantyMonths)),
              _row('دکان', item.shop),
              _row(
                  'قیمت',
                  item.price != null
                      ? 'Rs ${item.price!.toStringAsFixed(0)}'
                      : null),
              _row('سیریل نمبر', item.serial),
              _row('نوٹس', item.notes),
            ],
          ),
        );
      },
    );
  }
}
