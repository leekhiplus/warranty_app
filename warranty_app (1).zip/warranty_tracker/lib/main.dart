import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'home_screen.dart';
import 'notification_service.dart';
import 'settings.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  final settings = AppSettings();
  await settings.load();
  final store = WarrantyStore(settings);
  await store.load();
  // پرانا ڈیٹا اپ ڈیٹ ہونے پر یاد دہانیاں نئے سرے سے لگا دیں
  await store.rescheduleAll();
  runApp(WarrantyApp(store: store));
}

class WarrantyApp extends StatelessWidget {
  final WarrantyStore store;
  const WarrantyApp({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'وارنٹی ٹریکر',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ur'),
      supportedLocales: const [Locale('ur'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF00796B),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
        ),
      ),
      home: HomeScreen(store: store),
    );
  }
}
