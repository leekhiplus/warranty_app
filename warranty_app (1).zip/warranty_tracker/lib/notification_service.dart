import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'settings.dart';
import 'warranty_item.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static const int _slots = 6;

  static const NotificationDetails _details = NotificationDetails(
    android: AndroidNotificationDetails(
      'warranty_channel',
      'وارنٹی یاد دہانی',
      channelDescription: 'وارنٹی ختم ہونے کی اطلاع',
      importance: Importance.high,
      priority: Priority.high,
    ),
  );

  static int _base(WarrantyItem item) => (item.id % 200000000) * _slots;

  static Future<void> init() async {
    try {
      tzdata.initializeTimeZones();
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
      await _plugin.initialize(const InitializationSettings(android: android));
      final impl = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      await impl?.requestNotificationsPermission();
    } catch (_) {}
  }

  static Future<void> cancelFor(WarrantyItem item) async {
    try {
      for (var i = 0; i < _slots; i++) {
        await _plugin.cancel(_base(item) + i);
      }
    } catch (_) {}
  }

  static Future<void> scheduleFor(WarrantyItem item, AppSettings s) async {
    try {
      await cancelFor(item);
      final now = DateTime.now();
      final e = item.expiryDate;
      for (var i = 0; i < s.offsets.length && i < _slots; i++) {
        final days = s.offsets[i];
        final when = DateTime(e.year, e.month, e.day - days, s.hour);
        if (when.isBefore(now)) continue;
        final body = days == 0
            ? '${item.name} کی وارنٹی آج ختم ہو رہی ہے'
            : '${item.name} کی وارنٹی $days دن میں ختم ہو جائے گی';
        await _plugin.zonedSchedule(
          _base(item) + i,
          'وارنٹی یاد دہانی',
          body,
          tz.TZDateTime.from(when, tz.local),
          _details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
        );
      }
    } catch (_) {}
  }

  /// تمام یاد دہانیاں دوبارہ بنانا (سیٹنگ بدلنے یا ایپ کھلنے پر)
  static Future<void> rescheduleAll(
      List<WarrantyItem> items, AppSettings s) async {
    try {
      await _plugin.cancelAll();
    } catch (_) {}
    for (final it in items) {
      await scheduleFor(it, s);
    }
  }

  static Future<void> showTest() async {
    try {
      await _plugin.show(
        2000000000,
        'وارنٹی ٹریکر',
        'ٹیسٹ کامیاب: یاد دہانیاں ٹھیک کام کر رہی ہیں',
        _details,
      );
    } catch (_) {}
  }
}
