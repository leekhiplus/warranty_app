import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'warranty_item.dart';

class ExportService {
  static String _esc(String s) => '"${s.replaceAll('"', '""')}"';

  static Future<void> exportCsv(List<WarrantyItem> items) async {
    final rows = <List<String>>[
      [
        'نام',
        'تاریخ خرید',
        'مدت (ماہ)',
        'ختم ہونے کی تاریخ',
        'باقی دن',
        'دکان',
        'قیمت',
        'سیریل نمبر',
        'سروس سینٹر',
        'نوٹس',
      ],
      for (final i in items)
        [
          i.name,
          fmtDate(i.purchaseDate),
          '${i.warrantyMonths}',
          fmtDate(i.expiryDate),
          '${i.daysLeft}',
          i.shop ?? '',
          i.price != null ? i.price!.toStringAsFixed(0) : '',
          i.serial ?? '',
          i.servicePhone ?? '',
          i.notes ?? '',
        ],
    ];
    final csv =
        '\uFEFF${rows.map((r) => r.map(_esc).join(',')).join('\r\n')}';
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/warranty_report.csv');
    await f.writeAsString(csv);
    await Share.shareXFiles(
      [XFile(f.path, mimeType: 'text/csv')],
      text: 'وارنٹی رپورٹ',
    );
  }

  static Future<void> shareItem(WarrantyItem i) async {
    final b = StringBuffer()
      ..writeln('📦 ${i.name}')
      ..writeln('تاریخ خرید: ${fmtDate(i.purchaseDate)}')
      ..writeln('وارنٹی: ${warrantyLabel(i.warrantyMonths)}')
      ..writeln('ختم ہونے کی تاریخ: ${fmtDate(i.expiryDate)}');
    if (i.shop != null) b.writeln('دکان: ${i.shop}');
    if (i.price != null) b.writeln('قیمت: Rs ${i.price!.toStringAsFixed(0)}');
    if (i.serial != null) b.writeln('سیریل نمبر: ${i.serial}');
    if (i.servicePhone != null) b.writeln('سروس سینٹر: ${i.servicePhone}');
    final files = i.imagePaths
        .where((p) => File(p).existsSync())
        .map((p) => XFile(p))
        .toList();
    if (files.isEmpty) {
      await Share.share(b.toString());
    } else {
      await Share.shareXFiles(files, text: b.toString());
    }
  }
}
