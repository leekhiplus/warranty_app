import 'package:flutter/material.dart';
import 'notification_service.dart';
import 'store.dart';

class SettingsScreen extends StatelessWidget {
  final WarrantyStore store;
  const SettingsScreen({super.key, required this.store});

  String _offsetLabel(int d) => d == 0 ? 'جس دن ختم ہو' : '$d دن پہلے';

  String _hourLabel(int h) {
    final suffix = h >= 12 ? 'شام/دوپہر' : 'صبح';
    final h12 = h % 12 == 0 ? 12 : h % 12;
    return '$h12:00 $suffix';
  }

  @override
  Widget build(BuildContext context) {
    final s = store.settings;
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(title: const Text('سیٹنگز')),
          body: ListView(
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 4),
                child: Text('یاد دہانی کب دی جائے',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
              for (final d in const [60, 30, 14, 7, 1, 0])
                CheckboxListTile(
                  title: Text(_offsetLabel(d)),
                  value: s.offsets.contains(d),
                  onChanged: (v) async {
                    final list = List<int>.from(s.offsets);
                    if (v == true) {
                      list.add(d);
                    } else {
                      list.remove(d);
                    }
                    await s.setOffsets(list);
                    await store.rescheduleAll();
                  },
                ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.access_time),
                title: const Text('یاد دہانی کا وقت'),
                subtitle: Text(_hourLabel(s.hour)),
                onTap: () async {
                  final t = await showTimePicker(
                    context: context,
                    initialTime: TimeOfDay(hour: s.hour, minute: 0),
                  );
                  if (t != null) {
                    await s.setHour(t.hour);
                    await store.rescheduleAll();
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.notifications_active),
                title: const Text('ٹیسٹ نوٹیفکیشن بھیجیں'),
                subtitle: const Text(
                    'اگر نوٹیفکیشن نہ آئے تو فون کی سیٹنگز میں ایپ کے نوٹیفکیشن آن کریں'),
                onTap: NotificationService.showTest,
              ),
            ],
          ),
        );
      },
    );
  }
}
