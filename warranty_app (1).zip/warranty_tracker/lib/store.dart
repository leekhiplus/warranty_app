import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'notification_service.dart';
import 'settings.dart';
import 'warranty_item.dart';

class WarrantyStore extends ChangeNotifier {
  static const _key = 'warranty_items_v1';
  final AppSettings settings;
  final List<WarrantyItem> _items = [];

  WarrantyStore(this.settings);

  List<WarrantyItem> get items => List<WarrantyItem>.unmodifiable(_items);

  List<WarrantyItem> get sorted {
    final l = List<WarrantyItem>.from(_items);
    l.sort((a, b) {
      final ea = a.isExpired ? 1 : 0;
      final eb = b.isExpired ? 1 : 0;
      if (ea != eb) return ea.compareTo(eb);
      return a.expiryDate.compareTo(b.expiryDate);
    });
    return l;
  }

  int get count => _items.length;
  int get activeCount => _items.where((e) => !e.isExpired).length;
  int get soonCount =>
      _items.where((e) => !e.isExpired && e.daysLeft <= 30).length;
  int get expiredCount => _items.where((e) => e.isExpired).length;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString(_key);
    _items.clear();
    if (s != null) {
      try {
        final list = jsonDecode(s) as List;
        for (final e in list) {
          _items.add(WarrantyItem.fromJson(Map<String, dynamic>.from(e)));
        }
      } catch (_) {}
    }
    notifyListeners();
  }

  Future<void> _persist() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
        _key, jsonEncode(_items.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  Future<void> rescheduleAll() =>
      NotificationService.rescheduleAll(_items, settings);

  Future<void> add(WarrantyItem item) async {
    _items.add(item);
    await _persist();
    await NotificationService.scheduleFor(item, settings);
  }

  Future<void> update(WarrantyItem item) async {
    final i = _items.indexWhere((e) => e.id == item.id);
    if (i == -1) return;
    final oldPaths = List<String>.from(_items[i].imagePaths);
    _items[i] = item;
    for (final p in oldPaths) {
      if (!item.imagePaths.contains(p)) _deleteFile(p);
    }
    await _persist();
    await NotificationService.scheduleFor(item, settings);
  }

  Future<void> remove(WarrantyItem item) async {
    _items.removeWhere((e) => e.id == item.id);
    for (final p in item.imagePaths) {
      _deleteFile(p);
    }
    await NotificationService.cancelFor(item);
    await _persist();
  }

  void _deleteFile(String path) {
    try {
      final f = File(path);
      if (f.existsSync()) f.deleteSync();
    } catch (_) {}
  }
}
