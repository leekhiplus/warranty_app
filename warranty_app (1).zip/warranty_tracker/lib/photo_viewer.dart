import 'dart:io';
import 'package:flutter/material.dart';

class PhotoViewer extends StatelessWidget {
  final List<String> paths;
  final int initialIndex;
  const PhotoViewer({super.key, required this.paths, this.initialIndex = 0});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
      ),
      body: PageView.builder(
        controller: PageController(initialPage: initialIndex),
        itemCount: paths.length,
        itemBuilder: (_, i) => InteractiveViewer(
          child: Center(
            child: Image.file(
              File(paths[i]),
              errorBuilder: (_, __, ___) => const Icon(Icons.broken_image,
                  color: Colors.white, size: 64),
            ),
          ),
        ),
      ),
    );
  }
}
