import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings extends ChangeNotifier {
  static const _kOffsets = 'reminder_offsets_v1';
  static const _kHour = 'reminder_hour_v1';

  /// ممکنہ یاد دہانی کے دن (ختم ہونے سے کتنے دن پہلے)
  static const List<int> allOffsets = [60, 30, 14, 7, 1, 0];

  List<int> offsets = [30, 7, 0];
  int hour = 9;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final list = p.getStringList(_kOffsets);
    if (list != null) {
      offsets = list.map((e) => int.tryParse(e)).whereType<int>().toList();
    }
    hour = p.getInt(_kHour) ?? 9;
    _normalize();
  }

  void _normalize() {
    offsets = offsets.where(allOffsets.contains).toSet().toList()
      ..sort((a, b) => b.compareTo(a));
  }

  Future<void> setOffsets(List<int> v) async {
    offsets = List<int>.from(v);
    _normalize();
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_kOffsets, offsets.map((e) => '$e').toList());
    notifyListeners();
  }

  Future<void> setHour(int h) async {
    hour = h;
    final p = await SharedPreferences.getInstance();
    await p.setInt(_kHour, h);
    notifyListeners();
  }
}
