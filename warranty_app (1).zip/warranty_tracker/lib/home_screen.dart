import 'dart:io';
import 'package:flutter/material.dart';
import 'add_edit_screen.dart';
import 'detail_screen.dart';
import 'export_service.dart';
import 'settings_screen.dart';
import 'store.dart';
import 'warranty_item.dart';

Color statusColor(WarrantyItem i) {
  if (i.isExpired) return Colors.red.shade700;
  if (i.daysLeft <= 30) return Colors.orange.shade800;
  return Colors.green.shade700;
}

String statusText(WarrantyItem i) {
  if (i.isExpired) return 'وارنٹی ختم ہو چکی';
  if (i.daysLeft == 0) return 'آج ختم ہو رہی ہے';
  return 'باقی ${i.daysLeft} دن';
}

class HomeScreen extends StatefulWidget {
  final WarrantyStore store;
  const HomeScreen({super.key, required this.store});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _query = '';
  int _filter = 0; // 0 سب، 1 جلد ختم، 2 ختم شدہ

  List<WarrantyItem> _filtered() {
    Iterable<WarrantyItem> l = widget.store.sorted;
    if (_filter == 1) l = l.where((e) => !e.isExpired && e.daysLeft <= 30);
    if (_filter == 2) l = l.where((e) => e.isExpired);
    final q = _query.trim().toLowerCase();
    if (q.isNotEmpty) {
      l = l.where((e) =>
          e.name.toLowerCase().contains(q) ||
          (e.shop ?? '').toLowerCase().contains(q) ||
          (e.serial ?? '').toLowerCase().contains(q));
    }
    return l.toList();
  }

  Future<void> _export() async {
    if (widget.store.count == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ایکسپورٹ کے لیے کوئی ریکارڈ نہیں')));
      return;
    }
    try {
      await ExportService.exportCsv(widget.store.sorted);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ایکسپورٹ نہیں ہو سکا')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = widget.store;
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final items = _filtered();
        return Scaffold(
          appBar: AppBar(
            title: const Text('وارنٹی ٹریکر'),
            actions: [
              IconButton(
                tooltip: 'ایکسپورٹ (CSV)',
                icon: const Icon(Icons.ios_share),
                onPressed: _export,
              ),
              IconButton(
                tooltip: 'سیٹنگز',
                icon: const Icon(Icons.settings),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => SettingsScreen(store: store)),
                ),
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => AddEditScreen(store: store)),
            ),
            icon: const Icon(Icons.add_a_photo),
            label: const Text('نئی رسید'),
          ),
          body: store.count == 0
              ? const _EmptyView()
              : ListView(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 96),
                  children: [
                    _SummaryRow(store: store),
                    const SizedBox(height: 8),
                    TextField(
                      decoration: const InputDecoration(
                        hintText: 'نام، دکان یا سیریل نمبر سے تلاش کریں',
                        prefixIcon: Icon(Icons.search),
                        isDense: true,
                      ),
                      onChanged: (v) => setState(() => _query = v),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: [
                        for (final e in const [
                          [0, 'سب'],
                          [1, 'جلد ختم'],
                          [2, 'ختم شدہ'],
                        ])
                          ChoiceChip(
                            label: Text(e[1] as String),
                            selected: _filter == e[0],
                            onSelected: (_) =>
                                setState(() => _filter = e[0] as int),
                          ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (items.isEmpty)
                      const Padding(
                        padding: EdgeInsets.all(32),
                        child: Center(child: Text('کوئی نتیجہ نہیں ملا')),
                      ),
                    for (final it in items) _ItemCard(item: it, store: store),
                  ],
                ),
        );
      },
    );
  }
}

class _EmptyView extends StatelessWidget {
  const _EmptyView();
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.receipt_long,
                size: 90, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 16),
            const Text('ابھی کوئی رسید محفوظ نہیں',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text(
              'نیچے "نئی رسید" دبا کر رسید کی تصویر اور وارنٹی کی تفصیل محفوظ کریں۔ ختم ہونے سے پہلے ایپ آپ کو یاد دلائے گی۔',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final WarrantyStore store;
  const _SummaryRow({required this.store});

  Widget _box(String label, int n, Color c) => Expanded(
        child: Card(
          color: c.withOpacity(0.12),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Column(
              children: [
                Text('$n',
                    style: TextStyle(
                        fontSize: 24, fontWeight: FontWeight.bold, color: c)),
                Text(label, style: TextStyle(color: c)),
              ],
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _box('چالو', store.activeCount, Colors.green.shade700),
        _box('جلد ختم', store.soonCount, Colors.orange.shade800),
        _box('ختم', store.expiredCount, Colors.red.shade700),
      ],
    );
  }
}

class _ItemCard extends StatelessWidget {
  final WarrantyItem item;
  final WarrantyStore store;
  const _ItemCard({required this.item, required this.store});

  @override
  Widget build(BuildContext context) {
    final color = statusColor(item);
    final thumb = item.imagePaths.isNotEmpty ? item.imagePaths.first : null;
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(10),
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: SizedBox(
            width: 56,
            height: 56,
            child: thumb != null
                ? Image.file(
                    File(thumb),
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        const Icon(Icons.broken_image),
                  )
                : Container(
                    color: Colors.grey.shade200,
                    child: const Icon(Icons.receipt_long),
                  ),
          ),
        ),
        title: Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('ختم ہونے کی تاریخ: ${fmtDate(item.expiryDate)}'),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(statusText(item),
              style: TextStyle(
                  color: color, fontWeight: FontWeight.bold, fontSize: 12)),
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => DetailScreen(store: store, itemId: item.id)),
        ),
      ),
    );
  }
}
