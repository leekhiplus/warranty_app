import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'store.dart';
import 'warranty_item.dart';

class AddEditScreen extends StatefulWidget {
  final WarrantyStore store;
  final WarrantyItem? item;
  const AddEditScreen({super.key, required this.store, this.item});

  @override
  State<AddEditScreen> createState() => _AddEditScreenState();
}

class _AddEditScreenState extends State<AddEditScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _shop;
  late final TextEditingController _price;
  late final TextEditingController _serial;
  late final TextEditingController _notes;
  late final TextEditingController _months;
  late DateTime _purchaseDate;
  String? _imagePath;
  bool _saving = false;

  static const _quickMonths = [3, 6, 12, 24, 36, 60];

  @override
  void initState() {
    super.initState();
    final it = widget.item;
    _name = TextEditingController(text: it?.name ?? '');
    _shop = TextEditingController(text: it?.shop ?? '');
    _price = TextEditingController(
        text: it?.price != null ? it!.price!.toStringAsFixed(0) : '');
    _serial = TextEditingController(text: it?.serial ?? '');
    _notes = TextEditingController(text: it?.notes ?? '');
    _months = TextEditingController(text: '${it?.warrantyMonths ?? 12}');
    _purchaseDate = it?.purchaseDate ?? DateTime.now();
    _imagePath = it?.imagePath;
  }

  @override
  void dispose() {
    _name.dispose();
    _shop.dispose();
    _price.dispose();
    _serial.dispose();
    _notes.dispose();
    _months.dispose();
    super.dispose();
  }

  Future<void> _pick(ImageSource source) async {
    try {
      final x = await ImagePicker()
          .pickImage(source: source, maxWidth: 1800, imageQuality: 80);
      if (x == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final path =
          '${dir.path}/receipt_${DateTime.now().millisecondsSinceEpoch}.jpg';
      await File(x.path).copy(path);
      if (!mounted) return;
      setState(() => _imagePath = path);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تصویر حاصل نہیں ہو سکی')));
    }
  }

  void _showPickSheet() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('کیمرے سے تصویر لیں'),
              onTap: () {
                Navigator.pop(ctx);
                _pick(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('گیلری سے چنیں'),
              onTap: () {
                Navigator.pop(ctx);
                _pick(ImageSource.gallery);
              },
            ),
            if (_imagePath != null)
              ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('تصویر ہٹائیں'),
                onTap: () {
                  Navigator.pop(ctx);
                  setState(() => _imagePath = null);
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _purchaseDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (d != null) setState(() => _purchaseDate = d);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    String? clean(String s) => s.trim().isEmpty ? null : s.trim();
    final item = WarrantyItem(
      id: widget.item?.id ??
          DateTime.now().millisecondsSinceEpoch % 500000000,
      name: _name.text.trim(),
      shop: clean(_shop.text),
      price: double.tryParse(_price.text.trim()),
      serial: clean(_serial.text),
      notes: clean(_notes.text),
      purchaseDate: _purchaseDate,
      warrantyMonths: int.parse(_months.text.trim()),
      imagePath: _imagePath,
    );
    if (widget.item == null) {
      await widget.store.add(item);
    } else {
      await widget.store.update(item);
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.item != null;
    final months = int.tryParse(_months.text.trim());
    return Scaffold(
      appBar: AppBar(title: Text(editing ? 'ترمیم' : 'نئی رسید')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            GestureDetector(
              onTap: _showPickSheet,
              child: Container(
                height: 180,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(12),
                ),
                clipBehavior: Clip.antiAlias,
                child: _imagePath != null
                    ? Image.file(File(_imagePath!),
                        fit: BoxFit.cover, width: double.infinity)
                    : const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.add_a_photo, size: 48),
                          SizedBox(height: 8),
                          Text('رسید یا وارنٹی کارڈ کی تصویر'),
                        ],
                      ),
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'پروڈکٹ کا نام *'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'نام لکھنا ضروری ہے' : null,
            ),
            const SizedBox(height: 12),
            InkWell(
              onTap: _pickDate,
              child: InputDecorator(
                decoration: const InputDecoration(labelText: 'تاریخ خرید'),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(fmtDate(_purchaseDate)),
                    const Icon(Icons.calendar_today, size: 18),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _months,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(
                  labelText: 'وارنٹی کی مدت (مہینوں میں) *'),
              onChanged: (_) => setState(() {}),
              validator: (v) {
                final n = int.tryParse((v ?? '').trim());
                if (n == null || n <= 0) return 'درست مدت لکھیں';
                if (n > 600) return 'مدت بہت زیادہ ہے';
                return null;
              },
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                for (final m in _quickMonths)
                  ChoiceChip(
                    label: Text(warrantyLabel(m)),
                    selected: months == m,
                    onSelected: (_) => setState(() => _months.text = '$m'),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _shop,
              decoration: const InputDecoration(labelText: 'دکان کا نام'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _price,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(labelText: 'قیمت (روپے)'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _serial,
              decoration: const InputDecoration(labelText: 'سیریل نمبر'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _notes,
              maxLines: 3,
              decoration: const InputDecoration(
                  labelText: 'نوٹس (مثلاً سروس سینٹر کا نمبر)'),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: const Icon(Icons.check),
              label: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('محفوظ کریں', style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
