DateTime addMonths(DateTime d, int months) {
  final total = d.month - 1 + months;
  final y = d.year + total ~/ 12;
  final m = total % 12 + 1;
  final lastDay = DateTime(y, m + 1, 0).day;
  return DateTime(y, m, d.day > lastDay ? lastDay : d.day);
}

String fmtDate(DateTime d) => '${d.day}/${d.month}/${d.year}';

String warrantyLabel(int months) {
  if (months % 12 == 0) return '${months ~/ 12} سال';
  return '$months ماہ';
}

class WarrantyItem {
  final int id;
  String name;
  String? shop;
  double? price;
  String? serial;
  String? notes;
  DateTime purchaseDate;
  int warrantyMonths;
  String? imagePath;

  WarrantyItem({
    required this.id,
    required this.name,
    required this.purchaseDate,
    required this.warrantyMonths,
    this.shop,
    this.price,
    this.serial,
    this.notes,
    this.imagePath,
  });

  DateTime get expiryDate => addMonths(purchaseDate, warrantyMonths);

  int get daysLeft {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final e = expiryDate;
    return DateTime(e.year, e.month, e.day).difference(today).inDays;
  }

  bool get isExpired => daysLeft < 0;

  double get progress {
    final total = expiryDate.difference(purchaseDate).inDays;
    if (total <= 0) return 1;
    final used = DateTime.now().difference(purchaseDate).inDays;
    return (used / total).clamp(0.0, 1.0);
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'shop': shop,
        'price': price,
        'serial': serial,
        'notes': notes,
        'purchaseDate': purchaseDate.toIso8601String(),
        'warrantyMonths': warrantyMonths,
        'imagePath': imagePath,
      };

  factory WarrantyItem.fromJson(Map<String, dynamic> j) => WarrantyItem(
        id: j['id'] as int,
        name: j['name'] as String,
        shop: j['shop'] as String?,
        price: (j['price'] as num?)?.toDouble(),
        serial: j['serial'] as String?,
        notes: j['notes'] as String?,
        purchaseDate: DateTime.parse(j['purchaseDate'] as String),
        warrantyMonths: j['warrantyMonths'] as int,
        imagePath: j['imagePath'] as String?,
      );
}
