import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'warranty_item.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  // وارنٹی ختم ہونے سے پہلے کتنے دن پر یاد دہانی دی جائے
  static const List<int> _offsets = [30, 7, 0];

  static Future<void> init() async {
    try {
      tzdata.initializeTimeZones();
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
      await _plugin.initialize(const InitializationSettings(android: android));
      final impl = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      await impl?.requestNotificationsPermission();
    } catch (_) {}
  }

  static Future<void> cancelFor(WarrantyItem item) async {
    try {
      for (var i = 0; i < _offsets.length; i++) {
        await _plugin.cancel(item.id * 3 + i);
      }
    } catch (_) {}
  }

  static Future<void> scheduleFor(WarrantyItem item) async {
    try {
      await cancelFor(item);
      final now = DateTime.now();
      final e = item.expiryDate;
      const details = NotificationDetails(
        android: AndroidNotificationDetails(
          'warranty_channel',
          'وارنٹی یاد دہانی',
          channelDescription: 'وارنٹی ختم ہونے کی اطلاع',
          importance: Importance.high,
          priority: Priority.high,
        ),
      );
      for (var i = 0; i < _offsets.length; i++) {
        final days = _offsets[i];
        final when = DateTime(e.year, e.month, e.day - days, 9);
        if (when.isBefore(now)) continue;
        final body = days == 0
            ? '${item.name} کی وارنٹی آج ختم ہو رہی ہے'
            : '${item.name} کی وارنٹی $days دن میں ختم ہو جائے گی';
        await _plugin.zonedSchedule(
          item.id * 3 + i,
          'وارنٹی یاد دہانی',
          body,
          tz.TZDateTime.from(when, tz.local),
          details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
        );
      }
    } catch (_) {}
  }
}
